using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SchoolHomeSchool
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Rectangle home, classroom, school, Blue, Red, Gold;
        Texture2D BlueTex,RedTex, GoldTex, OneTex, TwoTex, ThreeTex, homeTex, classTex, schoolTex;
        SpriteFont label;
        String LabelOne, LabelTwo, LabelThree, ClassLabel, HomeLabel, SchoolLabel;
        int timer, timerTwo, cycle, cycleTwo;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            timer = 0;
            cycle = 1;
            cycleTwo = 1;
            classroom = new Rectangle(0, 0, 266, 200);
            Red = new Rectangle (0, 0, 266, 200);
            school = new Rectangle(GraphicsDevice.Viewport.Width - 266, 0, 266, 200);
            Blue = new Rectangle((GraphicsDevice.Viewport.Width / 2) - 133, GraphicsDevice.Viewport.Height - 200, 266, 200);
            home = new Rectangle((GraphicsDevice.Viewport.Width / 2) - 133, GraphicsDevice.Viewport.Height - 200, 266, 200);
            Gold = new Rectangle(GraphicsDevice.Viewport.Width - 266, 0, 266, 200);
            LabelOne = "Classroom\nSlide";
            LabelTwo = "Home\nSlide";
            LabelThree = "School\nslide";
            ClassLabel = "Classroom\nSlide";
            HomeLabel = "Home\nSlide";
            SchoolLabel = "School\nslide";
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            homeTex = this.Content.Load<Texture2D>("Home");
            classTex = this.Content.Load<Texture2D>("Class");
            schoolTex = this.Content.Load<Texture2D>("School");
            RedTex = this.Content.Load<Texture2D>("Red");
            BlueTex = this.Content.Load<Texture2D>("Blue");
            GoldTex = this.Content.Load<Texture2D>("Gold");
            OneTex = this.Content.Load<Texture2D>("Red");
            TwoTex = this.Content.Load<Texture2D>("Blue");
            ThreeTex = this.Content.Load<Texture2D>("Gold");
            label = this.Content.Load<SpriteFont>("SpriteFont1");
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            timer++;
            timerTwo++;
            if (timer % 240 == 0)
            {
                if (cycleTwo == 1)
                {
                    LabelOne = SchoolLabel;
                    LabelTwo = ClassLabel;
                    LabelThree = HomeLabel;
                }
                else if (cycleTwo == 2)
                {
                    LabelOne = HomeLabel;
                    LabelTwo = SchoolLabel;
                    LabelThree = ClassLabel;
                }
                else if (cycleTwo == 3)
                {
                    LabelOne = ClassLabel;
                    LabelTwo = HomeLabel;
                    LabelThree = SchoolLabel;
                }

                cycleTwo++;

                if (cycleTwo > 3)
                {
                    cycleTwo = 1;
                }
            }

            if (timerTwo % 420 == 0)
            {
                if(cycle == 1)
                {
                    OneTex = BlueTex;
                    TwoTex = GoldTex;
                    ThreeTex = RedTex;
                    LabelOne = SchoolLabel;
                    LabelTwo = ClassLabel;
                    LabelThree = HomeLabel;
                }
                else if (cycle == 2)
                {
                    OneTex = GoldTex;
                    TwoTex = RedTex;
                    ThreeTex = BlueTex;
                    LabelOne = HomeLabel;
                    LabelTwo = SchoolLabel;
                    LabelThree = ClassLabel;
                }
                else if (cycle == 3)
                {
                    OneTex = RedTex;
                    TwoTex = BlueTex;
                    ThreeTex = GoldTex;
                    LabelOne = ClassLabel;
                    LabelTwo = HomeLabel;
                    LabelThree = SchoolLabel;
                }

                cycle++;

                if(cycle > 3)
                {
                    cycle = 1;
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            Vector2 TextOne = new Vector2(0,210);
            Vector2 TextTwo = new Vector2((GraphicsDevice.Viewport.Width / 2) - 133, 210);
            Vector2 TextThree = new Vector2(GraphicsDevice.Viewport.Width - 266, 210);
            // TODO: Add your drawing code here

            spriteBatch.Begin();
            spriteBatch.Draw(classTex,classroom,Color.White);
            spriteBatch.Draw(OneTex, Red, Color.White);
            spriteBatch.DrawString(label, LabelOne, TextOne, Color.White);
            spriteBatch.Draw(homeTex, home, Color.White);
            spriteBatch.Draw(TwoTex, Blue, Color.White);
            spriteBatch.DrawString(label, LabelTwo, TextTwo, Color.White);
            spriteBatch.Draw(schoolTex, school, Color.White);
            spriteBatch.Draw(ThreeTex, Gold, Color.White);
            spriteBatch.DrawString(label, LabelThree, TextThree, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
